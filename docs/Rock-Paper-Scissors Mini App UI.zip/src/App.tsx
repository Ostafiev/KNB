import { useState, useEffect, useRef, useCallback } from 'react'

type Screen =
  | 'splash'
  | 'home'
  | 'opponents'
  | 'create'
  | 'waiting'
  | 'battle'
  | 'result'
  | 'summary'

type Choice = 'rock' | 'paper' | 'scissors' | null
type Tab = 'random' | 'friends'
type Outcome = 'win' | 'lose' | 'draw'

const HAND_EMOJI: Record<NonNullable<Choice>, string> = {
  rock: '✊',
  paper: '✋',
  scissors: '✌️',
}

const CHOICE_LABEL: Record<NonNullable<Choice>, string> = {
  rock: 'Камень',
  paper: 'Бумага',
  scissors: 'Ножницы',
}

const BEATS: Record<NonNullable<Choice>, NonNullable<Choice>> = {
  rock: 'scissors',
  scissors: 'paper',
  paper: 'rock',
}

const OPPONENTS = [
  { id: 1, name: 'Алексей К.', avatar: '👨‍💻', rating: 1840, bet: 50, online: true },
  { id: 2, name: 'Мария Т.', avatar: '👩‍🎨', rating: 2110, bet: 120, online: true },
  { id: 3, name: 'Дмитрий Р.', avatar: '🧑‍🚀', rating: 990, bet: 25, online: false },
  { id: 4, name: 'Анна С.', avatar: '👩‍💼', rating: 1560, bet: 200, online: true },
  { id: 5, name: 'Иван П.', avatar: '🧑‍🍳', rating: 720, bet: 75, online: true },
]

const FRIENDS = [
  { id: 6, name: 'Сергей', avatar: '🤠', rating: 1300, bet: 100, online: true },
  { id: 7, name: 'Катя', avatar: '🧝‍♀️', rating: 1750, bet: 150, online: false },
  { id: 8, name: 'Паша', avatar: '🧑‍🎸', rating: 880, bet: 50, online: true },
]

// ─── Shared bottom sheet ─────────────────────────────────────────────────────

function BottomSheet({
  open,
  onClose,
  children,
}: {
  open: boolean
  onClose: () => void
  children: React.ReactNode
}) {
  if (!open) return null
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center"
      style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
      onClick={onClose}
    >
      <div
        className="glass-strong rounded-t-3xl w-full max-w-sm p-5 flex flex-col gap-2 animate-slide-up safe-bottom"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1 rounded-full bg-tg-subtext/30 mx-auto mb-2" />
        {children}
      </div>
    </div>
  )
}

function SheetRow({
  icon,
  label,
  sublabel,
  danger,
  onClick,
  right,
}: {
  icon: string
  label: string
  sublabel?: string
  danger?: boolean
  onClick?: () => void
  right?: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      className={`tappable glass rounded-2xl px-4 py-3.5 flex items-center gap-3 text-left w-full ${danger ? 'border border-tg-red/20' : ''}`}
    >
      <span className="text-xl flex-shrink-0">{icon}</span>
      <div className="flex-1 min-w-0">
        <div className={`text-sm font-semibold ${danger ? 'text-tg-red' : 'text-tg-text'}`}>{label}</div>
        {sublabel && <div className="text-tg-subtext text-xs mt-0.5">{sublabel}</div>}
      </div>
      {right ?? <span className="text-tg-subtext text-sm">›</span>}
    </button>
  )
}

// ─── Home menu sub-sheets ─────────────────────────────────────────────────────

type HomeSubSheet = 'profile' | 'support' | 'feedback' | 'faq' | null

function ProfileSheet({ onClose }: { onClose: () => void }) {
  const [sound, setSound] = useState(true)
  const [darkTheme, setDarkTheme] = useState(true)
  const [lang, setLang] = useState<'ru' | 'en'>('ru')

  return (
    <BottomSheet open onClose={onClose}>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-12 h-12 rounded-2xl glass-strong flex items-center justify-center text-2xl">🎮</div>
        <div>
          <div className="font-black text-tg-text">Никита Волков</div>
          <div className="text-tg-subtext text-xs">@nikita_volkov · ID 482910</div>
        </div>
        <button className="tappable ml-auto glass rounded-xl px-2.5 py-1 text-xs text-tg-blue-light border border-tg-blue/30">
          Изменить
        </button>
      </div>

      <div className="h-px bg-tg-border my-1" />

      {/* Language */}
      <div className="glass rounded-2xl px-4 py-3 flex items-center gap-3">
        <span className="text-xl">🌐</span>
        <span className="text-sm font-semibold text-tg-text flex-1">Язык</span>
        <div className="glass rounded-xl flex overflow-hidden">
          {(['ru', 'en'] as const).map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className="tappable px-3 py-1 text-xs font-bold transition-all duration-150"
              style={{
                background: lang === l ? '#2a9fd6' : 'transparent',
                color: lang === l ? '#fff' : '#8a9ab5',
              }}
            >
              {l.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Theme toggle */}
      <div className="glass rounded-2xl px-4 py-3 flex items-center gap-3">
        <span className="text-xl">🌙</span>
        <span className="text-sm font-semibold text-tg-text flex-1">Тёмная тема</span>
        <button
          onClick={() => setDarkTheme((v) => !v)}
          className="tappable w-11 h-6 rounded-full transition-all duration-200 relative"
          style={{ background: darkTheme ? '#2a9fd6' : 'rgba(255,255,255,0.15)' }}
        >
          <div
            className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all duration-200"
            style={{ left: darkTheme ? 22 : 2 }}
          />
        </button>
      </div>

      {/* Sound toggle */}
      <div className="glass rounded-2xl px-4 py-3 flex items-center gap-3">
        <span className="text-xl">{sound ? '🔊' : '🔇'}</span>
        <span className="text-sm font-semibold text-tg-text flex-1">Звук</span>
        <button
          onClick={() => setSound((v) => !v)}
          className="tappable w-11 h-6 rounded-full transition-all duration-200 relative"
          style={{ background: sound ? '#2aca5c' : 'rgba(255,255,255,0.15)' }}
        >
          <div
            className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all duration-200"
            style={{ left: sound ? 22 : 2 }}
          />
        </button>
      </div>

      <div className="h-px bg-tg-border my-1" />

      <SheetRow icon="📋" label="История транзакций" sublabel="Все пополнения и выводы" onClick={onClose} />
      <SheetRow icon="💳" label="Кошелёк" sublabel="Пополнить или вывести медяки" onClick={onClose} />
    </BottomSheet>
  )
}

function SupportSheet({ onClose }: { onClose: () => void }) {
  return (
    <BottomSheet open onClose={onClose}>
      <div className="text-center mb-1">
        <div className="text-4xl mb-2">💛</div>
        <div className="font-black text-tg-text text-base">Поддержать проект</div>
        <div className="text-tg-subtext text-xs mt-1 leading-relaxed">
          КНБ — независимый проект. Ваша поддержка помогает нам развиваться.
        </div>
      </div>
      <div className="h-px bg-tg-border my-1" />
      {[
        { icon: '☕', label: 'Чашка кофе', amount: '50 🪙', sub: 'Маленькое спасибо' },
        { icon: '🍕', label: 'Пицца разработчику', amount: '200 🪙', sub: 'Щедрый жест' },
        { icon: '🚀', label: 'Ракетное топливо', amount: '500 🪙', sub: 'Ты лучший!' },
      ].map(({ icon, label, amount, sub }) => (
        <button
          key={label}
          onClick={onClose}
          className="tappable glass rounded-2xl px-4 py-3.5 flex items-center gap-3 text-left w-full"
        >
          <span className="text-xl">{icon}</span>
          <div className="flex-1">
            <div className="text-sm font-semibold text-tg-text">{label}</div>
            <div className="text-tg-subtext text-xs">{sub}</div>
          </div>
          <span className="text-tg-yellow font-bold text-sm">{amount}</span>
        </button>
      ))}
      <button
        onClick={onClose}
        className="tappable glass rounded-2xl px-4 py-3 text-center text-tg-subtext text-sm"
      >
        Может в другой раз
      </button>
    </BottomSheet>
  )
}

function FeedbackSheet({ onClose }: { onClose: () => void }) {
  const [text, setText] = useState('')
  const [sent, setSent] = useState(false)

  if (sent) {
    return (
      <BottomSheet open onClose={onClose}>
        <div className="flex flex-col items-center gap-3 py-4">
          <div className="text-5xl animate-scale-in">✅</div>
          <div className="font-black text-tg-text">Спасибо!</div>
          <div className="text-tg-subtext text-sm text-center">Мы рассмотрим ваш отзыв в течение 24 часов.</div>
          <button onClick={onClose} className="tappable glass rounded-2xl px-6 py-3 text-sm font-semibold text-tg-text mt-1">
            Закрыть
          </button>
        </div>
      </BottomSheet>
    )
  }

  return (
    <BottomSheet open onClose={onClose}>
      <div className="font-black text-tg-text mb-1">Обратная связь</div>
      <div className="text-tg-subtext text-xs mb-3">Расскажите, что можно улучшить</div>

      {/* Category chips */}
      {(() => {
        const [cat, setCat] = useState<string>('bug')
        const cats = [
          { key: 'bug', label: '🐛 Ошибка' },
          { key: 'idea', label: '💡 Идея' },
          { key: 'other', label: '💬 Другое' },
        ]
        return (
          <div className="flex gap-2 mb-3">
            {cats.map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setCat(key)}
                className="tappable rounded-full px-3 py-1.5 text-xs font-semibold transition-all duration-150"
                style={{
                  background: cat === key ? '#2a9fd6' : 'rgba(255,255,255,0.06)',
                  color: cat === key ? '#fff' : '#8a9ab5',
                }}
              >
                {label}
              </button>
            ))}
          </div>
        )
      })()}

      <div className="glass rounded-2xl p-3 mb-3">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Опишите проблему или предложение..."
          rows={4}
          className="w-full bg-transparent text-tg-text text-sm outline-none resize-none placeholder:text-tg-subtext/50 leading-relaxed"
        />
        <div className="text-right text-tg-subtext text-xs mt-1">{text.length}/500</div>
      </div>

      <button
        onClick={() => text.trim().length > 0 && setSent(true)}
        className="tappable w-full py-3.5 rounded-2xl font-bold text-sm text-white transition-opacity"
        style={{
          background: 'linear-gradient(135deg, #2a9fd6 0%, #1a7ab8 100%)',
          opacity: text.trim().length > 0 ? 1 : 0.4,
        }}
      >
        Отправить отзыв
      </button>
    </BottomSheet>
  )
}

const FAQ_ITEMS = [
  { q: 'Как пополнить баланс медяков?', a: 'Перейдите в Профиль → Кошелёк. Там вы найдёте все доступные способы пополнения.' },
  { q: 'Что происходит при ничьей?', a: 'Ставки возвращаются обоим игрокам. Рейтинг не изменяется.' },
  { q: 'Как пригласить друга?', a: 'На главном экране нажмите «Пригласить», затем выберите контакт в Telegram. Друг получит прямую ссылку на матч.' },
  { q: 'Что случится, если время вышло?', a: 'Если вы не успели выбрать за 10 секунд, система автоматически делает ход за вас случайным образом.' },
  { q: 'Как связаться с поддержкой?', a: 'Используйте форму «Обратная связь» в этом меню или напишите нам в Telegram: @knb_support.' },
]

function FAQSheet({ onClose }: { onClose: () => void }) {
  const [open, setOpen] = useState<number | null>(null)

  return (
    <BottomSheet open onClose={onClose}>
      <div className="font-black text-tg-text mb-3">FAQ / Помощь</div>
      <div className="flex flex-col gap-2 max-h-80 overflow-y-auto" style={{ scrollbarWidth: 'none' }}>
        {FAQ_ITEMS.map(({ q, a }, i) => (
          <div key={i} className="glass rounded-2xl overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="tappable w-full px-4 py-3.5 flex items-start gap-3 text-left"
            >
              <span className="text-tg-blue-light text-sm mt-0.5 flex-shrink-0">Q</span>
              <span className="text-sm font-semibold text-tg-text flex-1">{q}</span>
              <span
                className="text-tg-subtext text-xs flex-shrink-0 transition-transform duration-200 mt-0.5"
                style={{ display: 'inline-block', transform: open === i ? 'rotate(180deg)' : 'rotate(0deg)' }}
              >
                ▾
              </span>
            </button>
            {open === i && (
              <div className="px-4 pb-3.5 animate-fade-in">
                <div className="h-px bg-tg-border mb-2.5" />
                <p className="text-tg-subtext text-sm leading-relaxed">{a}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </BottomSheet>
  )
}

// ─── Screens ────────────────────────────────────────────────────────────────

const HOW_TO_CARDS = [
  {
    icon: '🪙',
    title: 'Ставь медяки',
    body: 'Выбери соперника и сделай ставку медяками. Победитель забирает весь банк.',
    accent: '#ffd60a',
    bg: 'rgba(255, 214, 10, 0.12)',
  },
  {
    icon: '✊',
    title: 'Выбирай ход',
    body: 'Камень, Ножницы или Бумага — у тебя 10 секунд. Камень бьёт Ножницы, Ножницы режут Бумагу, Бумага накрывает Камень.',
    accent: '#2a9fd6',
    bg: 'rgba(42, 159, 214, 0.12)',
  },
  {
    icon: '🏆',
    title: 'Забирай приз',
    body: 'Победи — и медяки соперника твои. Пригласи друзей и задавай собственные условия пари.',
    accent: '#2aca5c',
    bg: 'rgba(42, 202, 92, 0.12)',
  },
]

function HowToPlayCard({
  card,
  index,
  active,
}: {
  card: (typeof HOW_TO_CARDS)[0]
  index: number
  active: boolean
}) {
  return (
    <div
      className="flex-shrink-0 w-full glass rounded-3xl p-6 flex flex-col gap-4 transition-all duration-300"
      style={{
        border: active ? `1px solid ${card.accent}44` : '1px solid rgba(255,255,255,0.06)',
        boxShadow: active ? `0 0 24px ${card.accent}22` : 'none',
      }}
    >
      <div
        className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl"
        style={{ background: card.bg }}
      >
        {card.icon}
      </div>
      <div>
        <div className="flex items-center gap-2 mb-1.5">
          <span
            className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-black text-tg-bg"
            style={{ background: card.accent }}
          >
            {index + 1}
          </span>
          <span className="font-black text-tg-text text-base">{card.title}</span>
        </div>
        <p className="text-tg-subtext text-sm leading-relaxed">{card.body}</p>
      </div>
    </div>
  )
}

function SplashScreen({ onPlay }: { onPlay: () => void }) {
  const [showHowTo, setShowHowTo] = useState(false)
  const [activeCard, setActiveCard] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)

  const handleScroll = useCallback(() => {
    const el = scrollRef.current
    if (!el) return
    const idx = Math.round(el.scrollLeft / el.offsetWidth)
    setActiveCard(idx)
  }, [])

  return (
    <div className="relative flex flex-col items-center justify-between min-h-screen mesh-bg overflow-hidden safe-top safe-bottom">
      {/* Animated rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="absolute w-72 h-72 rounded-full border border-tg-blue/20 animate-spin-slow" />
        <div
          className="absolute w-52 h-52 rounded-full border border-tg-blue/30"
          style={{ animation: 'spin-slow 5s linear infinite reverse' }}
        />
        <div className="absolute w-32 h-32 rounded-full border border-tg-blue-light/20 animate-spin-slow" />
      </div>

      <div className="relative flex-1 flex flex-col items-center justify-center gap-6 px-6 w-full animate-fade-in">
        {/* Logo */}
        <div className="relative">
          <div className="absolute inset-0 rounded-3xl glow-blue blur-xl opacity-60" />
          <div className="relative glass rounded-3xl p-5 flex flex-col items-center gap-3">
            <div className="flex gap-2 text-5xl animate-float">
              <span>✊</span>
              <span style={{ animationDelay: '0.3s' }} className="animate-float">✋</span>
              <span style={{ animationDelay: '0.6s' }} className="animate-float">✌️</span>
            </div>
            <div
              className="text-5xl font-black tracking-tight text-transparent bg-clip-text animate-gradient"
              style={{
                backgroundImage: 'linear-gradient(135deg, #64d2ff 0%, #2a9fd6 40%, #2aca5c 100%)',
              }}
            >
              КНБ
            </div>
            <div className="text-tg-subtext text-sm font-medium tracking-widest uppercase">
              Камень · Ножницы · Бумага
            </div>
          </div>
        </div>

        {!showHowTo ? (
          <>
            <p className="text-tg-subtext text-sm text-center leading-relaxed max-w-xs">
              Бросай вызов друзьям и незнакомцам.<br />
              Ставь медяки, побеждай, забирай всё.
            </p>
            <button
              onClick={() => setShowHowTo(true)}
              className="tappable glass rounded-2xl px-6 py-3 flex items-center gap-2 border border-tg-blue/30 text-tg-blue-light font-semibold text-sm"
            >
              <span>📖</span>
              <span>Как играть</span>
            </button>
          </>
        ) : (
          <div className="w-full flex flex-col gap-3 animate-slide-up">
            {/* Carousel */}
            <div
              ref={scrollRef}
              onScroll={handleScroll}
              className="flex overflow-x-auto snap-x snap-mandatory gap-3 pb-1"
              style={{ scrollbarWidth: 'none', WebkitOverflowScrolling: 'touch' }}
            >
              {HOW_TO_CARDS.map((card, i) => (
                <div key={i} className="snap-center flex-shrink-0 w-full">
                  <HowToPlayCard card={card} index={i} active={activeCard === i} />
                </div>
              ))}
            </div>
            {/* Dots */}
            <div className="flex justify-center gap-1.5">
              {HOW_TO_CARDS.map((_, i) => (
                <div
                  key={i}
                  className="rounded-full transition-all duration-300"
                  style={{
                    width: activeCard === i ? 18 : 6,
                    height: 6,
                    background: activeCard === i ? '#2a9fd6' : 'rgba(255,255,255,0.2)',
                  }}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="relative w-full px-6 pb-4 flex flex-col gap-3 animate-slide-up" style={{ animationDelay: '0.3s' }}>
        <button
          onClick={onPlay}
          className="tappable w-full py-4 rounded-2xl font-bold text-lg text-white relative overflow-hidden glow-blue"
          style={{ background: 'linear-gradient(135deg, #2a9fd6 0%, #1a7ab8 100%)' }}
        >
          <span className="relative z-10">Начать игру</span>
        </button>
        {showHowTo && (
          <button
            onClick={() => setShowHowTo(false)}
            className="tappable text-tg-subtext text-sm text-center"
          >
            Назад
          </button>
        )}
        <p className="text-center text-tg-subtext text-xs opacity-60">Версия 1.4.2 · 18+</p>
      </div>
    </div>
  )
}

// ─── Stat chip ───────────────────────────────────────────────────────────────
function StatChip({
  label,
  value,
  color,
}: {
  label: string
  value: string | number
  color: 'blue' | 'green' | 'red' | 'yellow'
}) {
  const colors = {
    blue: 'text-tg-blue-light',
    green: 'text-tg-green',
    red: 'text-tg-red',
    yellow: 'text-tg-yellow',
  }
  return (
    <div className="glass rounded-xl px-4 py-3 flex flex-col items-center gap-0.5">
      <span className={`text-xl font-black ${colors[color]}`}>{value}</span>
      <span className="text-tg-subtext text-xs font-medium">{label}</span>
    </div>
  )
}

function HomeScreen({
  onOpponents,
  onCreate,
}: {
  onOpponents: () => void
  onCreate: () => void
}) {
  const [gamesExpanded, setGamesExpanded] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [subSheet, setSubSheet] = useState<HomeSubSheet>(null)

  const openSub = (s: HomeSubSheet) => { setMenuOpen(false); setSubSheet(s) }

  return (
    <div className="flex flex-col min-h-screen mesh-bg safe-top safe-bottom px-4 gap-4">
      {/* Header */}
      <div className="flex items-center justify-between pt-2">
        <div className="text-xl font-black text-tg-text tracking-tight">КНБ</div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 glass rounded-full px-3 py-1.5">
            <span className="text-yellow-400 text-sm">🪙</span>
            <span className="text-sm font-bold text-tg-text font-mono">1,240</span>
          </div>
          <button
            onClick={() => setMenuOpen(true)}
            className="tappable w-9 h-9 glass rounded-xl flex items-center justify-center border border-tg-border"
            aria-label="Меню"
          >
            <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
              <rect y="0" width="16" height="2" rx="1" fill="#8a9ab5"/>
              <rect y="5" width="12" height="2" rx="1" fill="#8a9ab5"/>
              <rect y="10" width="8" height="2" rx="1" fill="#8a9ab5"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Main menu bottom sheet */}
      <BottomSheet open={menuOpen} onClose={() => setMenuOpen(false)}>
        <SheetRow icon="👤" label="Профиль" sublabel="Настройки, кошелёк, история" onClick={() => openSub('profile')} />
        <SheetRow icon="💛" label="Поддержать проект" sublabel="Помочь развитию КНБ" onClick={() => openSub('support')} />
        <SheetRow icon="✉️" label="Обратная связь" sublabel="Баг, идея, жалоба" onClick={() => openSub('feedback')} />
        <SheetRow icon="❓" label="FAQ / Помощь" sublabel="Частые вопросы" onClick={() => openSub('faq')} />
        <div className="h-px bg-tg-border my-1" />
        <SheetRow icon="🚪" label="Выйти из аккаунта" danger onClick={() => setMenuOpen(false)} right={null} />
      </BottomSheet>

      {/* Sub-sheets */}
      {subSheet === 'profile' && <ProfileSheet onClose={() => setSubSheet(null)} />}
      {subSheet === 'support' && <SupportSheet onClose={() => setSubSheet(null)} />}
      {subSheet === 'feedback' && <FeedbackSheet onClose={() => setSubSheet(null)} />}
      {subSheet === 'faq' && <FAQSheet onClose={() => setSubSheet(null)} />}

      {/* Profile card */}
      <div className="glass rounded-3xl p-5 animate-slide-up relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-10 rounded-3xl"
          style={{ background: 'linear-gradient(135deg, #2a9fd6 0%, #2aca5c 100%)' }}
        />
        <div className="relative flex items-center gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl glass-strong flex items-center justify-center text-4xl glow-blue">
              🎮
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-tg-green border-2 border-tg-bg" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-lg font-bold text-tg-text truncate">Никита Волков</div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-tg-blue-light text-sm">⚡</span>
              <span className="text-tg-subtext text-sm font-medium">Рейтинг</span>
              <span className="text-tg-blue-light font-bold text-sm ml-auto">1,840</span>
            </div>
            <div className="mt-1 h-1.5 rounded-full bg-tg-bg overflow-hidden">
              <div
                className="h-full rounded-full animate-gradient"
                style={{
                  width: '72%',
                  background: 'linear-gradient(90deg, #2a9fd6, #2aca5c)',
                }}
              />
            </div>
            <div className="text-tg-subtext text-xs mt-0.5">Мастер · до следующего уровня 160 pts</div>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2 mt-4">
          <StatChip label="Игры" value={318} color="blue" />
          <StatChip label="Победы" value={204} color="green" />
          <StatChip label="Поражения" value={89} color="red" />
          <StatChip label="Ничьи" value={25} color="yellow" />
        </div>
      </div>

      {/* Баланс медяков */}
      <div
        className="glass rounded-2xl p-4 flex items-center gap-4 animate-slide-up"
        style={{ animationDelay: '0.1s' }}
      >
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
          style={{ background: 'rgba(255, 214, 10, 0.15)' }}
        >
          🪙
        </div>
        <div className="flex-1">
          <div className="text-tg-subtext text-xs font-medium uppercase tracking-wider">Баланс медяков</div>
          <div className="text-2xl font-black text-tg-yellow">1,240 🪙</div>
        </div>
        <button
          className="tappable glass rounded-xl px-3 py-2 text-sm font-semibold text-tg-blue-light border border-tg-blue/30"
        >
          Пополнить
        </button>
      </div>

      {/* Action buttons — 3 equal columns */}
      <div
        className="grid grid-cols-3 gap-2 animate-slide-up"
        style={{ animationDelay: '0.15s' }}
      >
        <button
          onClick={onOpponents}
          className="tappable glass rounded-2xl p-3 flex flex-col gap-1.5 border border-tg-blue/30 glow-blue"
        >
          <span className="text-2xl">⚔️</span>
          <span className="text-xs font-bold text-tg-text leading-tight">Найти бой</span>
          <span className="text-tg-subtext" style={{ fontSize: 10 }}>Играй сейчас</span>
        </button>
        <button
          onClick={onCreate}
          className="tappable glass rounded-2xl p-3 flex flex-col gap-1.5 border border-tg-green/30 glow-green"
        >
          <span className="text-2xl">✏️</span>
          <span className="text-xs font-bold text-tg-text leading-tight">Создать игру</span>
          <span className="text-tg-subtext" style={{ fontSize: 10 }}>Задай условия</span>
        </button>
        <button
          className="tappable glass rounded-2xl p-3 flex flex-col gap-1.5 border border-tg-yellow/30"
          style={{ boxShadow: '0 0 16px rgba(255,214,10,0.15)' }}
        >
          <span className="text-2xl">🔗</span>
          <span className="text-xs font-bold text-tg-text leading-tight">Пригласить</span>
          <span className="text-tg-subtext" style={{ fontSize: 10 }}>Поделиться</span>
        </button>
      </div>

      {/* Friends button */}
      <button
        className="tappable glass rounded-2xl p-4 flex items-center gap-4 animate-slide-up border border-tg-border"
        style={{ animationDelay: '0.2s' }}
      >
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
          style={{ background: 'rgba(42, 159, 214, 0.15)' }}
        >
          👥
        </div>
        <div className="flex-1 text-left">
          <div className="text-sm font-bold text-tg-text">Друзья</div>
          <div className="text-tg-subtext text-xs">3 онлайн сейчас</div>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-tg-blue flex items-center justify-center text-xs font-bold text-white">
            3
          </div>
          <span className="text-tg-subtext text-sm">›</span>
        </div>
      </button>

      {/* Recent activity — collapsible accordion */}
      {(() => {
        const ALL_GAMES = [
          { opp: 'Алексей К.', result: 'win', stars: '+50', hand: '✊', time: '2 мин назад' },
          { opp: 'Мария Т.', result: 'lose', stars: '-120', hand: '✌️', time: '18 мин назад' },
          { opp: 'Незнакомец', result: 'draw', stars: '0', hand: '✋', time: '1 ч назад' },
          { opp: 'Дмитрий Р.', result: 'win', stars: '+25', hand: '✋', time: '3 ч назад' },
          { opp: 'Анна С.', result: 'lose', stars: '-200', hand: '✊', time: 'вчера' },
        ]
        const visible = gamesExpanded ? ALL_GAMES : ALL_GAMES.slice(0, 3)
        return (
          <div className="animate-slide-up" style={{ animationDelay: '0.25s' }}>
            <button
              onClick={() => setGamesExpanded((v) => !v)}
              className="tappable w-full flex items-center justify-between mb-2 px-1"
            >
              <span className="text-tg-subtext text-xs font-semibold uppercase tracking-widest">
                Последние игры
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-tg-subtext text-xs">{gamesExpanded ? 'Свернуть' : `+${ALL_GAMES.length - 3} ещё`}</span>
                <span
                  className="text-tg-subtext text-xs transition-transform duration-200"
                  style={{ display: 'inline-block', transform: gamesExpanded ? 'rotate(180deg)' : 'rotate(0deg)' }}
                >
                  ▾
                </span>
              </div>
            </button>
            <div className="flex flex-col gap-2">
              {visible.map((game, i) => (
                <div
                  key={i}
                  className="glass rounded-xl px-4 py-3 flex items-center gap-3 animate-fade-in"
                  style={{ animationDelay: `${i * 0.04}s` }}
                >
                  <span className="text-xl">{game.hand}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-tg-text truncate">{game.opp}</div>
                    <div className="text-tg-subtext text-xs">{game.time}</div>
                  </div>
                  <span
                    className={`text-sm font-bold font-mono ${
                      game.result === 'win'
                        ? 'text-tg-green'
                        : game.result === 'lose'
                        ? 'text-tg-red'
                        : 'text-tg-subtext'
                    }`}
                  >
                    {game.stars} 🪙
                  </span>
                </div>
              ))}
            </div>
          </div>
        )
      })()}
    </div>
  )
}

type BetFilter = 'all' | 'low' | 'mid' | 'high'
type SortBy = 'stake' | 'online' | 'rating'

function OpponentsScreen({
  onSelect,
  onBack,
}: {
  onSelect: (name: string, bet: number) => void
  onBack: () => void
}) {
  const [tab, setTab] = useState<Tab>('random')
  const [betFilter, setBetFilter] = useState<BetFilter>('all')
  const [sortBy, setSortBy] = useState<SortBy>('online')
  const [skillOnly, setSkillOnly] = useState(false)

  const baseList = tab === 'random' ? OPPONENTS : FRIENDS

  const filtered = baseList
    .filter((p) => {
      if (betFilter === 'low') return p.bet <= 10
      if (betFilter === 'mid') return p.bet > 10 && p.bet <= 50
      if (betFilter === 'high') return p.bet > 50
      return true
    })
    .filter((p) => !skillOnly || p.rating >= 1500)
    .sort((a, b) => {
      if (sortBy === 'stake') return b.bet - a.bet
      if (sortBy === 'rating') return b.rating - a.rating
      return (b.online ? 1 : 0) - (a.online ? 1 : 0)
    })

  const list = filtered

  return (
    <div className="flex flex-col min-h-screen mesh-bg safe-top safe-bottom">
      {/* Nav */}
      <div className="flex items-center gap-3 px-4 pt-2 pb-3">
        <button onClick={onBack} className="tappable w-9 h-9 glass rounded-xl flex items-center justify-center text-tg-subtext">
          ‹
        </button>
        <h1 className="font-black text-lg text-tg-text flex-1">Выбор соперника</h1>
        <div className="glass rounded-full px-2.5 py-1 text-xs text-tg-green font-semibold flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-tg-green inline-block" />
          {OPPONENTS.filter((o) => o.online).length + FRIENDS.filter((f) => f.online).length} онлайн
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 mb-3">
        <div className="glass rounded-2xl p-1 flex gap-1">
          <button
            onClick={() => setTab('random')}
            className={`tappable flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 ${
              tab === 'random'
                ? 'bg-tg-blue text-white glow-blue'
                : 'text-tg-subtext'
            }`}
          >
            ⚡ Случайный бой
          </button>
          <button
            onClick={() => setTab('friends')}
            className={`tappable flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 ${
              tab === 'friends'
                ? 'bg-tg-blue text-white glow-blue'
                : 'text-tg-subtext'
            }`}
          >
            👥 Друзья
          </button>
        </div>
      </div>

      {/* Filter bar */}
      <div className="px-4 mb-3 flex flex-col gap-2">
        {/* Bet range chips */}
        <div className="flex gap-2 overflow-x-auto pb-0.5" style={{ scrollbarWidth: 'none' }}>
          {([
            { key: 'all', label: 'Любая ставка' },
            { key: 'low', label: '≤ 10 🪙' },
            { key: 'mid', label: '10–50 🪙' },
            { key: 'high', label: '50+ 🪙' },
          ] as { key: BetFilter; label: string }[]).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setBetFilter(key)}
              className="tappable flex-shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold transition-all duration-150"
              style={{
                background: betFilter === key ? '#2a9fd6' : 'rgba(255,255,255,0.06)',
                color: betFilter === key ? '#fff' : '#8a9ab5',
                border: betFilter === key ? '1px solid #2a9fd644' : '1px solid transparent',
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Sort + skill toggle row */}
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5 flex-1">
            {([
              { key: 'online', label: 'Онлайн' },
              { key: 'stake', label: 'Ставка' },
              { key: 'rating', label: 'Рейтинг' },
            ] as { key: SortBy; label: string }[]).map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setSortBy(key)}
                className="tappable rounded-lg px-2.5 py-1 text-xs font-medium transition-all duration-150"
                style={{
                  background: sortBy === key ? 'rgba(42,159,214,0.2)' : 'rgba(255,255,255,0.05)',
                  color: sortBy === key ? '#64d2ff' : '#8a9ab5',
                }}
              >
                {sortBy === key ? '↓ ' : ''}{label}
              </button>
            ))}
          </div>
          {/* Skill toggle */}
          <button
            onClick={() => setSkillOnly((v) => !v)}
            className="tappable flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium transition-all duration-150 flex-shrink-0"
            style={{
              background: skillOnly ? 'rgba(42, 202, 92, 0.18)' : 'rgba(255,255,255,0.05)',
              color: skillOnly ? '#2aca5c' : '#8a9ab5',
              border: skillOnly ? '1px solid rgba(42,202,92,0.3)' : '1px solid transparent',
            }}
          >
            <span>{skillOnly ? '✓' : ''}</span>
            <span>1500+ pts</span>
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="px-4 mb-3">
        <div className="glass rounded-xl flex items-center gap-3 px-4 py-3">
          <span className="text-tg-subtext text-sm">🔍</span>
          <input
            placeholder="Поиск игроков..."
            className="flex-1 bg-transparent text-tg-text text-sm outline-none placeholder:text-tg-subtext/60"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-4 flex flex-col gap-2 pb-4">
        {list.length === 0 && (
          <div className="glass rounded-2xl p-8 flex flex-col items-center gap-3 text-center">
            <span className="text-4xl">🔍</span>
            <div className="text-tg-text font-bold">Нет игроков</div>
            <div className="text-tg-subtext text-sm">Попробуй изменить фильтры</div>
          </div>
        )}
        {list.map((player, i) => (
          <button
            key={player.id}
            onClick={() => onSelect(player.name, player.bet)}
            className="tappable glass rounded-2xl p-4 flex items-center gap-3 text-left border border-tg-border hover:border-tg-blue/40 transition-colors animate-slide-up"
            style={{ animationDelay: `${i * 0.06}s` }}
          >
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl glass-strong flex items-center justify-center text-2xl">
                {player.avatar}
              </div>
              <div
                className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-tg-bg ${
                  player.online ? 'bg-tg-green' : 'bg-tg-subtext/40'
                }`}
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-tg-text truncate">{player.name}</div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-tg-blue-light text-xs">⚡</span>
                <span className="text-tg-subtext text-xs">{player.rating.toLocaleString()} pts</span>
              </div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <div className="glass rounded-lg px-2.5 py-1 flex items-center gap-1">
                <span className="text-xs text-tg-yellow">🪙</span>
                <span className="text-sm font-bold text-tg-text">{player.bet}</span>
              </div>
              <span className="text-tg-subtext text-xs">медяков</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

function CreateScreen({
  onCreate,
  onBack,
}: {
  onCreate: (stars: number, condition: string) => void
  onBack: () => void
}) {
  const [stars, setStars] = useState(100)
  const [condition, setCondition] = useState('')
  const presets = [25, 50, 100, 250, 500]

  return (
    <div className="flex flex-col min-h-screen mesh-bg safe-top safe-bottom px-4">
      {/* Nav */}
      <div className="flex items-center gap-3 pt-2 pb-5">
        <button onClick={onBack} className="tappable w-9 h-9 glass rounded-xl flex items-center justify-center text-tg-subtext">
          ‹
        </button>
        <h1 className="font-black text-lg text-tg-text flex-1">Создать игру</h1>
      </div>

      <div className="flex flex-col gap-5 animate-fade-in">
        {/* Медяки input */}
        <div className="glass rounded-3xl p-5">
          <div className="text-tg-subtext text-xs font-semibold uppercase tracking-wider mb-4">
            Ставка медяками
          </div>
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <div
                className="absolute inset-0 rounded-2xl glow-yellow blur-lg opacity-40"
                style={{ background: '#ffd60a' }}
              />
              <div className="relative glass-strong rounded-2xl px-8 py-4 flex items-center gap-3">
                <span className="text-3xl">🪙</span>
                <span className="text-4xl font-black text-tg-yellow">{stars}</span>
              </div>
            </div>

            <input
              type="range"
              min={10}
              max={1000}
              step={10}
              value={stars}
              onChange={(e) => setStars(Number(e.target.value))}
              className="w-full h-2 rounded-full appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #ffd60a ${(stars - 10) / 9.9}%, rgba(255,255,255,0.1) ${(stars - 10) / 9.9}%)`,
              }}
            />

            <div className="flex gap-2 flex-wrap justify-center">
              {presets.map((p) => (
                <button
                  key={p}
                  onClick={() => setStars(p)}
                  className={`tappable rounded-xl px-3 py-1.5 text-sm font-bold transition-all duration-150 ${
                    stars === p
                      ? 'bg-tg-yellow text-tg-bg'
                      : 'glass text-tg-subtext border border-tg-border'
                  }`}
                >
                  {p} 🪙
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Condition */}
        <div className="glass rounded-3xl p-5">
          <div className="text-tg-subtext text-xs font-semibold uppercase tracking-wider mb-3">
            Условие пари (необязательно)
          </div>
          <textarea
            value={condition}
            onChange={(e) => setCondition(e.target.value)}
            placeholder="Например: проигравший делает 20 отжиманий..."
            rows={3}
            className="w-full bg-transparent text-tg-text text-sm outline-none resize-none placeholder:text-tg-subtext/50 leading-relaxed"
          />
          {condition.length > 0 && (
            <div className="mt-2 text-tg-subtext text-xs text-right">{condition.length}/200</div>
          )}
        </div>

        {/* Summary */}
        <div className="glass rounded-2xl p-4 flex items-center gap-3 border border-tg-blue/20">
          <span className="text-xl">📋</span>
          <div className="flex-1">
            <div className="text-tg-subtext text-xs">Итоговая ставка</div>
            <div className="text-sm font-bold text-tg-text">
              {stars} 🪙 · {condition ? `"${condition.slice(0, 40)}${condition.length > 40 ? '…' : ''}"` : 'без дополнительных условий'}
            </div>
          </div>
        </div>

        {/* Two action buttons */}
        <div className="flex flex-col gap-3">
          <button
            onClick={() => onCreate(stars, condition)}
            className="tappable w-full py-4 rounded-2xl font-bold text-base text-white relative overflow-hidden glow-blue flex items-center justify-center gap-2"
            style={{ background: 'linear-gradient(135deg, #2a9fd6 0%, #1a7ab8 100%)' }}
          >
            <span className="text-xl">⚔️</span>
            <span>Создать игру</span>
          </button>
          <button
            onClick={() => {
              // Simulates Telegram native share sheet
              if (navigator.share) {
                navigator.share({
                  title: 'КНБ — вызов на дуэль!',
                  text: `Сыграем? Ставка: ${stars} 🪙${condition ? `\nУсловие: ${condition}` : ''}`,
                  url: 'https://t.me/knb_bot?start=game_' + Math.random().toString(36).slice(2, 8),
                }).catch(() => {})
              }
            }}
            className="tappable w-full py-4 rounded-2xl font-bold text-base glass border border-tg-green/40 text-tg-green flex items-center justify-center gap-2"
            style={{ boxShadow: '0 0 18px rgba(42,202,92,0.18)' }}
          >
            <span className="text-xl">📨</span>
            <span>Пригласить</span>
          </button>
        </div>

        <p className="text-center text-tg-subtext text-xs">
          «Пригласить» откроет Telegram для выбора контакта
        </p>
      </div>
    </div>
  )
}

function WaitingScreen({ onCancel, bet }: { onCancel: () => void; bet: number }) {
  const [dots, setDots] = useState(0)

  useEffect(() => {
    const t = setInterval(() => setDots((d) => (d + 1) % 4), 500)
    return () => clearInterval(t)
  }, [])

  return (
    <div className="flex flex-col min-h-screen mesh-bg safe-top safe-bottom items-center justify-between px-6">
      <div className="pt-6">
        <div className="text-tg-subtext text-xs font-semibold uppercase tracking-widest text-center">
          Ставка · {bet} 🪙
        </div>
      </div>

      <div className="flex flex-col items-center gap-8 animate-fade-in">
        {/* Pulsing animation */}
        <div className="relative flex items-center justify-center w-48 h-48">
          {[1, 2, 3].map((ring) => (
            <div
              key={ring}
              className="absolute rounded-full border border-tg-blue/30"
              style={{
                width: `${ring * 56}px`,
                height: `${ring * 56}px`,
                animation: `pulse-ring 2s cubic-bezier(0.215, 0.61, 0.355, 1) ${ring * 0.3}s infinite`,
              }}
            />
          ))}
          <div className="relative z-10 w-20 h-20 rounded-full glass-strong flex items-center justify-center text-4xl animate-pulse-core glow-blue">
            ⏳
          </div>
        </div>

        <div className="flex flex-col items-center gap-2">
          <h2 className="text-2xl font-black text-tg-text">
            Поиск соперника{'.'.repeat(dots)}
          </h2>
          <p className="text-tg-subtext text-sm text-center max-w-xs">
            Ищем игрока с похожим рейтингом и ставкой
          </p>
        </div>

        {/* Stats while waiting */}
        <div className="flex gap-3">
          <div className="glass rounded-xl px-4 py-3 text-center">
            <div className="text-tg-blue-light font-bold text-lg">142</div>
            <div className="text-tg-subtext text-xs">в поиске</div>
          </div>
          <div className="glass rounded-xl px-4 py-3 text-center">
            <div className="text-tg-green font-bold text-lg">~8s</div>
            <div className="text-tg-subtext text-xs">среднее время</div>
          </div>
        </div>
      </div>

      <div className="w-full pb-4">
        <button
          onClick={onCancel}
          className="tappable w-full py-4 rounded-2xl font-bold text-tg-red glass border border-tg-red/30"
        >
          Отменить поиск
        </button>
      </div>
    </div>
  )
}

function BattleScreen({
  onChoice,
  onSurrender,
  opponentName,
}: {
  onChoice: (choice: Choice) => void
  onSurrender: () => void
  opponentName: string
}) {
  const [countdown, setCountdown] = useState(3)
  const [phase, setPhase] = useState<'countdown' | 'choose'>('countdown')
  const [selected, setSelected] = useState<Choice>(null)
  const [shaking, setShaking] = useState(false)
  const [roundTimer, setRoundTimer] = useState(10)
  const [showSurrender, setShowSurrender] = useState(false)
  const [showMenu, setShowMenu] = useState(false)

  useEffect(() => {
    if (countdown > 0) {
      const t = setTimeout(() => setCountdown((c) => c - 1), 1000)
      return () => clearTimeout(t)
    } else {
      setPhase('choose')
      setShaking(true)
      const t2 = setTimeout(() => setShaking(false), 2000)
      return () => clearTimeout(t2)
    }
  }, [countdown])

  // Round countdown once choosing phase starts
  useEffect(() => {
    if (phase !== 'choose' || selected) return
    if (roundTimer <= 0) {
      // Auto-pick random on timeout
      const choices: NonNullable<Choice>[] = ['rock', 'paper', 'scissors']
      onChoice(choices[Math.floor(Math.random() * 3)])
      return
    }
    const t = setTimeout(() => setRoundTimer((v) => v - 1), 1000)
    return () => clearTimeout(t)
  }, [phase, roundTimer, selected, onChoice])

  const handlePick = (c: Choice) => {
    if (selected || phase !== 'choose') return
    setSelected(c)
    setTimeout(() => onChoice(c), 600)
  }

  const choices: NonNullable<Choice>[] = ['rock', 'paper', 'scissors']
  const choiceIcons = ['✊', '✋', '✌️']
  const timerUrgent = roundTimer <= 3

  return (
    <div className="flex flex-col min-h-screen mesh-bg safe-top safe-bottom relative">
      {/* Top icon row: X (left gap) and ⋯ menu — separated by at least 8px, both right-anchored */}
      <div className="absolute top-0 right-0 z-10 flex items-center gap-2 px-4 pt-3" style={{ paddingTop: 'max(env(safe-area-inset-top), 12px)' }}>
        <button
          onClick={() => setShowMenu(true)}
          className="tappable w-8 h-8 rounded-xl glass flex items-center justify-center text-tg-subtext border border-tg-border"
          aria-label="Меню"
        >
          ⋯
        </button>
        <button
          onClick={() => setShowSurrender(true)}
          className="tappable w-8 h-8 rounded-xl glass flex items-center justify-center text-tg-subtext border border-tg-border"
          aria-label="Сдаться"
        >
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M1 1l10 10M11 1L1 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </button>
      </div>

      {/* Persistent round timer — topmost content element */}
      {phase === 'choose' && (
        <div className="px-4 pt-2 mb-1">
          <div
            className="glass rounded-xl px-4 py-2 flex items-center gap-3"
            style={{
              border: timerUrgent ? '1px solid rgba(229,82,82,0.4)' : '1px solid rgba(255,255,255,0.06)',
              boxShadow: timerUrgent ? '0 0 16px rgba(229,82,82,0.2)' : 'none',
            }}
          >
            <div className="flex-1 h-1.5 rounded-full overflow-hidden bg-tg-bg">
              <div
                className="h-full rounded-full transition-all duration-1000"
                style={{
                  width: `${(roundTimer / 10) * 100}%`,
                  background: timerUrgent
                    ? 'linear-gradient(90deg, #e55252, #ff8c8c)'
                    : 'linear-gradient(90deg, #2a9fd6, #64d2ff)',
                }}
              />
            </div>
            <span
              className={`font-black text-sm font-mono w-6 text-right transition-colors duration-300 ${
                timerUrgent ? 'text-tg-red' : 'text-tg-blue-light'
              }`}
            >
              {roundTimer}
            </span>
            <span className="text-tg-subtext text-xs">сек</span>
          </div>
        </div>
      )}

      {/* Opponent bar — below timer, avatar+name left-aligned */}
      <div className="px-4 pb-2">
        <div className="glass rounded-2xl p-3 flex items-center gap-3 opacity-75">
          <div className="w-9 h-9 rounded-xl glass-strong flex items-center justify-center text-lg flex-shrink-0">
            👤
          </div>
          <div className="min-w-0">
            <div className="text-xs text-tg-subtext">Соперник</div>
            <div className="text-sm font-semibold text-tg-subtext truncate max-w-36">{opponentName}</div>
          </div>
          <div className="ml-auto flex items-center gap-1 glass rounded-lg px-2 py-1">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-1.5 h-1.5 rounded-full bg-tg-subtext/60"
                style={{ animation: `pulse-core 1.2s ${i * 0.3}s ease-in-out infinite` }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Arena */}
      <div className="flex-1 flex flex-col items-center justify-center gap-6 px-4">
        {phase === 'countdown' ? (
          <div className="flex flex-col items-center gap-4">
            <div
              key={countdown}
              className="text-9xl font-black text-transparent bg-clip-text"
              style={{
                backgroundImage: 'linear-gradient(135deg, #64d2ff, #2a9fd6)',
                animation: 'countdown 1s ease forwards',
              }}
            >
              {countdown === 0 ? '🥊' : countdown}
            </div>
            <p className="text-tg-subtext text-sm animate-fade-in">Приготовься…</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4 w-full animate-fade-in">
            <div className="flex items-center justify-center gap-8">
              {/* LEFT = opponent */}
              <div className={`text-6xl ${shaking ? 'animate-shake' : 'animate-float'}`}>✊</div>
              <div className="glass rounded-full w-10 h-10 flex items-center justify-center text-tg-red font-black text-sm glow-red">
                VS
              </div>
              {/* RIGHT = player */}
              <div
                className={`text-6xl ${shaking ? 'animate-shake' : 'animate-float'}`}
                style={{ animationDelay: '0.15s' }}
              >
                ✊
              </div>
            </div>
            {!selected && (
              <p className={`font-bold text-lg transition-colors duration-300 ${timerUrgent ? 'text-tg-red text-glow-red' : 'text-tg-text text-glow-blue'}`}>
                {timerUrgent ? 'Быстрее!' : 'Выбирай!'}
              </p>
            )}
          </div>
        )}
      </div>

      {/* Bottom — player side (highlighted with accent border) */}
      <div className="px-4 pb-4">
        {/* Player label — name+avatar right-aligned */}
        <div
          className="glass rounded-2xl px-4 py-2 mb-3 flex items-center gap-3"
          style={{ border: '1px solid rgba(42,159,214,0.4)', boxShadow: '0 0 18px rgba(42,159,214,0.15)' }}
        >
          {/* Spacer pushes content to the right */}
          <div className="flex-1" />
          <div className="text-right min-w-0">
            <div className="text-xs text-tg-blue-light font-semibold">Ты</div>
            <div className="text-sm font-bold text-tg-text truncate max-w-36">Никита В.</div>
          </div>
          <div className="w-8 h-8 rounded-xl glass-strong flex items-center justify-center text-base flex-shrink-0">
            🎮
          </div>
        </div>

        {/* Choice buttons */}
        <div className="grid grid-cols-3 gap-3">
          {choices.map((c, i) => (
            <button
              key={c}
              onClick={() => handlePick(c)}
              disabled={phase !== 'choose' || selected !== null}
              className={`tappable rounded-2xl py-5 flex flex-col items-center gap-2 transition-all duration-200 border-2 ${
                selected === c
                  ? 'border-tg-blue glow-blue scale-95 glass-strong'
                  : 'glass border-tg-border'
              } ${phase !== 'choose' ? 'opacity-40' : ''}`}
            >
              <span className="text-4xl">{choiceIcons[i]}</span>
              <span className="text-tg-subtext text-xs font-medium">{CHOICE_LABEL[c]}</span>
            </button>
          ))}
        </div>

        {selected && (
          <div className="mt-3 text-center text-tg-subtext text-sm animate-fade-in">
            Ждём хода соперника…
          </div>
        )}
      </div>

      {/* Surrender confirmation dialog */}
      {showSurrender && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center"
          style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
        >
          <div className="glass-strong rounded-t-3xl w-full max-w-sm p-6 flex flex-col gap-4 animate-slide-up safe-bottom">
            <div className="text-center">
              <div className="text-4xl mb-2">🏳️</div>
              <div className="text-lg font-black text-tg-text">Сдаться?</div>
              <div className="text-tg-subtext text-sm mt-1">
                Ты потеряешь ставку и получишь поражение в рейтинге.
              </div>
            </div>
            <button
              onClick={() => { setShowSurrender(false); onSurrender() }}
              className="tappable w-full py-4 rounded-2xl font-bold text-tg-red glass border border-tg-red/40"
            >
              Да, сдаться
            </button>
            <button
              onClick={() => setShowSurrender(false)}
              className="tappable w-full py-3 rounded-2xl font-bold text-tg-text glass border border-tg-border"
            >
              Продолжить игру
            </button>
          </div>
        </div>
      )}

      {/* Menu sheet */}
      {showMenu && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center"
          style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
          onClick={() => setShowMenu(false)}
        >
          <div
            className="glass-strong rounded-t-3xl w-full max-w-sm p-5 flex flex-col gap-2 animate-slide-up safe-bottom"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-tg-subtext/30 mx-auto mb-2" />
            {[
              { icon: '🔇', label: 'Выключить звук' },
              { icon: '⚡', label: 'Скорость анимации' },
              { icon: '🐛', label: 'Сообщить об ошибке' },
            ].map(({ icon, label }) => (
              <button
                key={label}
                onClick={() => setShowMenu(false)}
                className="tappable glass rounded-2xl px-4 py-3.5 flex items-center gap-3 text-left"
              >
                <span className="text-xl">{icon}</span>
                <span className="text-sm font-semibold text-tg-text">{label}</span>
              </button>
            ))}
            <button
              onClick={() => setShowMenu(false)}
              className="tappable glass rounded-2xl px-4 py-3.5 flex items-center gap-3 text-left border border-tg-red/20"
            >
              <span className="text-xl">🚪</span>
              <span className="text-sm font-semibold text-tg-red">Покинуть матч</span>
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

function ResultScreen({
  playerChoice,
  opponentChoice,
  outcome,
  opponentName,
  bet,
  onContinue,
}: {
  playerChoice: NonNullable<Choice>
  opponentChoice: NonNullable<Choice>
  outcome: Outcome
  opponentName: string
  bet: number
  onContinue: () => void
}) {
  const [showResult, setShowResult] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setShowResult(true), 800)
    return () => clearTimeout(t)
  }, [])

  const outcomeConfig = {
    win: {
      label: 'ПОБЕДА!',
      color: 'text-tg-green',
      glow: 'text-glow-green',
      emoji: '🏆',
      stars: `+${bet}`,
      starsColor: 'text-tg-green',
      bg: 'rgba(42, 202, 92, 0.08)',
    },
    lose: {
      label: 'ПОРАЖЕНИЕ',
      color: 'text-tg-red',
      glow: 'text-glow-red',
      emoji: '💀',
      stars: `-${bet}`,
      starsColor: 'text-tg-red',
      bg: 'rgba(229, 82, 82, 0.08)',
    },
    draw: {
      label: 'НИЧЬЯ',
      color: 'text-tg-yellow',
      glow: '',
      emoji: '🤝',
      stars: '±0',
      starsColor: 'text-tg-subtext',
      bg: 'rgba(255, 214, 10, 0.08)',
    },
  }

  const cfg = outcomeConfig[outcome]

  return (
    <div className="flex flex-col min-h-screen mesh-bg safe-top safe-bottom items-center px-4">
      {/* Opponent info */}
      <div className="w-full pt-4 pb-2">
        <div className="glass rounded-2xl px-4 py-3 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl glass-strong flex items-center justify-center text-lg">
            👤
          </div>
          <span className="text-sm font-bold text-tg-text">{opponentName}</span>
        </div>
      </div>

      {/* Collision — opponent LEFT, player RIGHT */}
      <div className="flex-1 flex flex-col items-center justify-center gap-6">
        <div className="flex items-center justify-center gap-6">
          {/* LEFT = opponent */}
          <div className={`text-7xl animate-collision-left ${outcome === 'lose' ? 'animate-float' : ''}`}>
            {HAND_EMOJI[opponentChoice]}
          </div>
          <div className="flex flex-col items-center">
            <div
              className="glass rounded-full w-12 h-12 flex items-center justify-center text-xl"
              style={{ background: cfg.bg }}
            >
              💥
            </div>
          </div>
          {/* RIGHT = player */}
          <div className={`text-7xl animate-collision-right ${outcome === 'win' ? 'animate-float' : ''}`}>
            {HAND_EMOJI[playerChoice]}
          </div>
        </div>

        {showResult && (
          <div className="flex flex-col items-center gap-3 animate-scale-in">
            <div className="text-5xl">{cfg.emoji}</div>
            <div className={`text-4xl font-black ${cfg.color} ${cfg.glow}`}>
              {cfg.label}
            </div>
            <div className="glass rounded-2xl px-6 py-3 flex items-center gap-2">
              <span className="text-lg">🪙</span>
              <span className={`text-2xl font-black ${cfg.starsColor}`}>{cfg.stars}</span>
            </div>
          </div>
        )}
      </div>

      <div className="w-full pb-4">
        <button
          onClick={onContinue}
          className="tappable w-full py-4 rounded-2xl font-bold text-lg text-white glow-blue"
          style={{ background: 'linear-gradient(135deg, #2a9fd6 0%, #1a7ab8 100%)' }}
        >
          Далее
        </button>
      </div>
    </div>
  )
}

// ─── Rematch condition editor (inline inside summary) ────────────────────────

function RematchConditionEditor({
  bet,
  onBetChange,
  condition,
  onConditionChange,
}: {
  bet: number
  onBetChange: (v: number) => void
  condition: string
  onConditionChange: (v: string) => void
}) {
  const presets = [25, 50, 100, 250, 500]
  return (
    <div className="flex flex-col gap-3 animate-slide-up">
      <div className="glass rounded-2xl p-4">
        <div className="text-tg-subtext text-xs font-semibold uppercase tracking-wider mb-3">Ставка медяков</div>
        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">🪙</span>
          <span className="text-3xl font-black text-tg-yellow">{bet}</span>
        </div>
        <input
          type="range" min={10} max={1000} step={10} value={bet}
          onChange={(e) => onBetChange(Number(e.target.value))}
          className="w-full h-2 rounded-full appearance-none cursor-pointer mb-3"
          style={{ background: `linear-gradient(to right, #ffd60a ${(bet - 10) / 9.9}%, rgba(255,255,255,0.1) ${(bet - 10) / 9.9}%)` }}
        />
        <div className="flex gap-2 flex-wrap">
          {presets.map((p) => (
            <button key={p} onClick={() => onBetChange(p)}
              className="tappable rounded-xl px-3 py-1.5 text-xs font-bold transition-all duration-150"
              style={{ background: bet === p ? '#ffd60a' : 'rgba(255,255,255,0.07)', color: bet === p ? '#17212b' : '#8a9ab5' }}>
              {p} 🪙
            </button>
          ))}
        </div>
      </div>
      <div className="glass rounded-2xl p-4">
        <div className="text-tg-subtext text-xs font-semibold uppercase tracking-wider mb-2">Условие (необязательно)</div>
        <textarea value={condition} onChange={(e) => onConditionChange(e.target.value)}
          placeholder="Например: проигравший пишет поздравление…"
          rows={2}
          className="w-full bg-transparent text-tg-text text-sm outline-none resize-none placeholder:text-tg-subtext/50 leading-relaxed" />
      </div>
    </div>
  )
}

// ─── Opponent confirmation sheet (mockup) ────────────────────────────────────

function RematchConfirmSheet({
  opponentName,
  bet,
  condition,
  onAccept,
  onDecline,
  onEditConditions,
}: {
  opponentName: string
  bet: number
  condition: string
  onAccept: () => void
  onDecline: () => void
  onEditConditions: () => void
}) {
  return (
    <BottomSheet open onClose={onDecline}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-3">
        <div className="w-11 h-11 rounded-2xl glass-strong flex items-center justify-center text-2xl flex-shrink-0">👤</div>
        <div className="flex-1 min-w-0">
          <div className="font-black text-tg-text">Реванш?</div>
          <div className="text-tg-subtext text-xs truncate">{opponentName} запрашивает реванш</div>
        </div>
        <div className="glass rounded-full px-2.5 py-1 flex items-center gap-1 flex-shrink-0">
          <span className="text-xs">🪙</span>
          <span className="text-sm font-black text-tg-yellow">{bet}</span>
        </div>
      </div>

      {/* Conditions summary */}
      <div className="glass rounded-2xl p-4 mb-1 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <span className="text-tg-subtext text-xs uppercase tracking-wider">Ставка</span>
          <span className="text-sm font-bold text-tg-text">{bet} 🪙</span>
        </div>
        <div className="h-px bg-tg-border" />
        <div className="flex items-start justify-between gap-3">
          <span className="text-tg-subtext text-xs uppercase tracking-wider flex-shrink-0">Условие</span>
          <span className="text-sm text-tg-text text-right">
            {condition.trim() ? `"${condition}"` : <span className="text-tg-subtext/60 italic">без доп. условий</span>}
          </span>
        </div>
      </div>

      {/* Edit conditions link */}
      <button onClick={onEditConditions}
        className="tappable text-tg-blue-light text-xs font-semibold text-center w-full py-1.5 mb-1">
        ✏️ Изменить условия
      </button>

      <div className="h-px bg-tg-border mb-1" />

      <button onClick={onAccept}
        className="tappable w-full py-4 rounded-2xl font-bold text-base text-white glow-green mb-1"
        style={{ background: 'linear-gradient(135deg, #2aca5c 0%, #1a8c40 100%)' }}>
        ✅ Принять
      </button>
      <button onClick={onDecline}
        className="tappable w-full py-3.5 rounded-2xl font-bold text-sm glass border border-tg-red/30 text-tg-red">
        ✗ Отклонить
      </button>
    </BottomSheet>
  )
}

// ─── Summary screen ───────────────────────────────────────────────────────────

type RematchPhase = 'idle' | 'waiting' | 'editing' | 'opponent-confirm'

function SummaryScreen({
  outcome,
  playerChoice,
  opponentChoice,
  opponentName,
  bet: initialBet,
  onRematch,
  onMenu,
}: {
  outcome: Outcome
  playerChoice: NonNullable<Choice>
  opponentChoice: NonNullable<Choice>
  opponentName: string
  bet: number
  onRematch: () => void
  onMenu: () => void
}) {
  const [rematchPhase, setRematchPhase] = useState<RematchPhase>('idle')
  const [rematchBet, setRematchBet] = useState(initialBet)
  const [rematchCondition, setRematchCondition] = useState('')
  const [waitDots, setWaitDots] = useState(0)

  const starsDelta = outcome === 'win' ? initialBet : outcome === 'lose' ? -initialBet : 0

  // Animate waiting dots
  useEffect(() => {
    if (rematchPhase !== 'waiting') return
    const t = setInterval(() => setWaitDots((d) => (d + 1) % 4), 500)
    return () => clearInterval(t)
  }, [rematchPhase])

  // Simulate opponent responding after 4s (auto-shows confirm sheet for demo)
  useEffect(() => {
    if (rematchPhase !== 'waiting') return
    const t = setTimeout(() => setRematchPhase('opponent-confirm'), 4000)
    return () => clearTimeout(t)
  }, [rematchPhase])

  const handleRematchRequest = () => setRematchPhase('waiting')
  const handleCancelWait = () => setRematchPhase('idle')
  const handleEditFromWait = () => setRematchPhase('editing')
  const handleEditFromConfirm = () => setRematchPhase('editing')
  const handleSendEdited = () => setRematchPhase('waiting')
  const handleAccept = () => { setRematchPhase('idle'); onRematch() }
  const handleDecline = () => setRematchPhase('idle')

  return (
    <div className="flex flex-col min-h-screen mesh-bg safe-top safe-bottom px-4 gap-4">
      {/* Header */}
      <div className="text-center pt-4">
        <div className="text-tg-subtext text-xs uppercase tracking-widest mb-1">Итоги матча</div>
        <h1 className="text-2xl font-black text-tg-text">Матч завершён</h1>
      </div>

      {/* Score card */}
      <div className="glass rounded-3xl p-5 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-10 rounded-3xl"
          style={{
            background:
              outcome === 'win'
                ? 'linear-gradient(135deg, #2aca5c, #1a7a40)'
                : outcome === 'lose'
                ? 'linear-gradient(135deg, #e55252, #7a1a1a)'
                : 'linear-gradient(135deg, #ffd60a, #7a6500)',
          }}
        />
        <div className="relative flex items-center justify-between">
          {/* LEFT = opponent */}
          <div className="flex flex-col items-center gap-2">
            <div className="w-14 h-14 rounded-2xl glass-strong flex items-center justify-center text-3xl">👤</div>
            <div className="text-xs text-tg-subtext truncate max-w-16">{opponentName.split(' ')[0]}</div>
            <div className="text-3xl">{HAND_EMOJI[opponentChoice]}</div>
          </div>

          <div className="flex flex-col items-center gap-2">
            <div className={`text-2xl font-black ${outcome === 'win' ? 'text-tg-green text-glow-green' : outcome === 'lose' ? 'text-tg-red text-glow-red' : 'text-tg-yellow'}`}>
              {outcome === 'win' ? 'ПОБЕДА' : outcome === 'lose' ? 'ПРОИГРЫШ' : 'НИЧЬЯ'}
            </div>
            <div className="glass rounded-full px-3 py-1 flex items-center gap-1">
              <span className="text-sm">🪙</span>
              <span className={`font-black text-sm ${starsDelta > 0 ? 'text-tg-green' : starsDelta < 0 ? 'text-tg-red' : 'text-tg-subtext'}`}>
                {starsDelta > 0 ? '+' : ''}{starsDelta}
              </span>
            </div>
          </div>

          {/* RIGHT = player */}
          <div className="flex flex-col items-center gap-2">
            <div className="w-14 h-14 rounded-2xl glass-strong flex items-center justify-center text-3xl">🎮</div>
            <div className="text-xs text-tg-subtext truncate max-w-16">Никита В.</div>
            <div className="text-3xl">{HAND_EMOJI[playerChoice]}</div>
          </div>
        </div>
      </div>

      {/* Stats grid — opponent LEFT, player RIGHT */}
      <div className="grid grid-cols-2 gap-3">
        <div className="glass rounded-2xl p-4">
          <div className="text-tg-subtext text-xs uppercase tracking-wider mb-2">Его выбор</div>
          <div className="flex items-center gap-2">
            <span className="text-3xl">{HAND_EMOJI[opponentChoice]}</span>
            <span className="font-bold text-tg-text">{CHOICE_LABEL[opponentChoice]}</span>
          </div>
        </div>
        <div className="glass rounded-2xl p-4">
          <div className="text-tg-subtext text-xs uppercase tracking-wider mb-2">Никита В.</div>
          <div className="flex items-center gap-2">
            <span className="text-3xl">{HAND_EMOJI[playerChoice]}</span>
            <span className="font-bold text-tg-text">{CHOICE_LABEL[playerChoice]}</span>
          </div>
        </div>
      </div>

      {/* Reward */}
      <div className={`glass rounded-2xl p-4 flex items-center gap-4 border ${outcome === 'win' ? 'border-tg-green/30 glow-green' : outcome === 'lose' ? 'border-tg-red/30' : 'border-tg-yellow/30'}`}>
        <span className="text-3xl">{outcome === 'win' ? '🎁' : outcome === 'lose' ? '💸' : '🤝'}</span>
        <div className="flex-1">
          <div className="text-tg-subtext text-xs">
            {outcome === 'win' ? 'Ты заработал медяков' : outcome === 'lose' ? 'Ты потерял медяков' : 'Ничья'}
          </div>
          <div className={`text-xl font-black ${outcome === 'win' ? 'text-tg-green' : outcome === 'lose' ? 'text-tg-red' : 'text-tg-yellow'}`}>
            {starsDelta > 0 ? '+' : ''}{starsDelta} 🪙
          </div>
        </div>
        <div className="text-right">
          <div className="text-tg-subtext text-xs">Новый баланс</div>
          <div className="font-bold text-tg-text">{1240 + starsDelta} 🪙</div>
        </div>
      </div>

      {/* Condition editor (inline, replaces buttons when editing) */}
      {rematchPhase === 'editing' && (
        <>
          <RematchConditionEditor
            bet={rematchBet} onBetChange={setRematchBet}
            condition={rematchCondition} onConditionChange={setRematchCondition}
          />
          <div className="flex gap-3 mt-auto pb-2">
            <button onClick={() => setRematchPhase('idle')}
              className="tappable flex-1 py-3.5 rounded-2xl font-bold text-sm glass border border-tg-border text-tg-subtext">
              Отмена
            </button>
            <button onClick={handleSendEdited}
              className="tappable flex-[2] py-3.5 rounded-2xl font-bold text-sm text-white glow-blue"
              style={{ background: 'linear-gradient(135deg, #2a9fd6 0%, #1a7ab8 100%)' }}>
              Отправить реванш ⚔️
            </button>
          </div>
        </>
      )}

      {/* Default / waiting buttons */}
      {rematchPhase !== 'editing' && (
        <div className="flex flex-col gap-3 mt-auto pb-2">
          {rematchPhase === 'idle' && (
            <button onClick={handleRematchRequest}
              className="tappable w-full py-4 rounded-2xl font-bold text-lg text-white glow-blue"
              style={{ background: 'linear-gradient(135deg, #2a9fd6 0%, #1a7ab8 100%)' }}>
              ⚔️ Реванш
            </button>
          )}

          {rematchPhase === 'waiting' && (
            <div className="glass rounded-2xl p-4 flex flex-col gap-3 border border-tg-blue/20"
              style={{ boxShadow: '0 0 18px rgba(42,159,214,0.12)' }}>
              <div className="flex items-center gap-3">
                {/* Pulsing avatar */}
                <div className="relative flex-shrink-0">
                  <div className="absolute inset-0 rounded-xl bg-tg-blue/20 animate-pulse-ring" />
                  <div className="w-10 h-10 rounded-xl glass-strong flex items-center justify-center text-xl relative z-10">
                    👤
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold text-tg-text">
                    Ожидаем подтверждения{'.'.repeat(waitDots)}
                  </div>
                  <div className="text-tg-subtext text-xs truncate">от {opponentName}</div>
                </div>
                <div className="glass rounded-lg px-2.5 py-1 flex items-center gap-1 flex-shrink-0">
                  <span className="text-xs">🪙</span>
                  <span className="text-sm font-black text-tg-yellow">{rematchBet}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={handleEditFromWait}
                  className="tappable flex-1 py-2.5 rounded-xl text-xs font-semibold glass border border-tg-blue/30 text-tg-blue-light">
                  ✏️ Изменить условия
                </button>
                <button onClick={handleCancelWait}
                  className="tappable flex-1 py-2.5 rounded-xl text-xs font-semibold glass border border-tg-red/30 text-tg-red">
                  Отменить
                </button>
              </div>
            </div>
          )}

          <button onClick={onMenu}
            className="tappable w-full py-4 rounded-2xl font-bold text-base glass border border-tg-border text-tg-text">
            В главное меню
          </button>
        </div>
      )}

      {/* Opponent confirmation sheet */}
      {rematchPhase === 'opponent-confirm' && (
        <RematchConfirmSheet
          opponentName={opponentName}
          bet={rematchBet}
          condition={rematchCondition}
          onAccept={handleAccept}
          onDecline={handleDecline}
          onEditConditions={handleEditFromConfirm}
        />
      )}
    </div>
  )
}

// ─── Screen indicator ────────────────────────────────────────────────────────
const SCREEN_LABELS: Record<Screen, string> = {
  splash: '1. Заставка',
  home: '2. Главная',
  opponents: '3. Соперники',
  create: '4. Создать игру',
  waiting: '5. Ожидание',
  battle: '6. Бой',
  result: '7. Результат',
  summary: '8. Итоги',
}

const SCREEN_ORDER: Screen[] = [
  'splash', 'home', 'opponents', 'create', 'waiting', 'battle', 'result', 'summary',
]

// ─── Root ────────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>('splash')
  const [opponentName, setOpponentName] = useState('Мария Т.')
  const [bet, setBet] = useState(100)
  const [playerChoice, setPlayerChoice] = useState<NonNullable<Choice>>('rock')
  const [opponentChoice, setOpponentChoice] = useState<NonNullable<Choice>>('scissors')
  const [outcome, setOutcome] = useState<Outcome>('win')

  const go = (s: Screen) => setScreen(s)

  const handleOpponentSelect = (name: string, b: number) => {
    setOpponentName(name)
    setBet(b)
    go('waiting')
  }

  const handleCreate = (_stars: number, _cond: string) => {
    setBet(_stars)
    go('waiting')
  }

  // Simulate opponent found after 2s
  const waitingTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(() => {
    if (screen === 'waiting') {
      waitingTimer.current = setTimeout(() => go('battle'), 2500)
    }
    return () => {
      if (waitingTimer.current) clearTimeout(waitingTimer.current)
    }
  }, [screen])

  const handleChoice = (choice: Choice) => {
    if (!choice) return
    setPlayerChoice(choice)
    const choices: NonNullable<Choice>[] = ['rock', 'paper', 'scissors']
    const opp = choices[Math.floor(Math.random() * 3)]
    setOpponentChoice(opp)
    let out: Outcome = 'draw'
    if (BEATS[choice] === opp) out = 'win'
    else if (BEATS[opp] === choice) out = 'lose'
    setOutcome(out)
    go('result')
  }

  const currentIndex = SCREEN_ORDER.indexOf(screen)

  return (
    <div className="min-h-screen" style={{ background: '#17212b' }}>
      {/* Preview nav for demo */}
      <div
        className="fixed top-0 left-0 right-0 z-50 flex items-center gap-1.5 px-3 py-1.5 overflow-x-auto"
        style={{
          background: 'rgba(23, 33, 43, 0.95)',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
        }}
      >
        {SCREEN_ORDER.map((s, i) => (
          <button
            key={s}
            onClick={() => go(s)}
            className="tappable flex-shrink-0 rounded-lg px-2 py-1 text-xs font-medium transition-all duration-150"
            style={{
              background: screen === s ? '#2a9fd6' : 'rgba(255,255,255,0.06)',
              color: screen === s ? '#fff' : '#8a9ab5',
            }}
          >
            {i + 1}
          </button>
        ))}
        <span className="text-tg-subtext text-xs ml-1 flex-shrink-0 truncate max-w-28">
          {SCREEN_LABELS[screen]}
        </span>
      </div>

      {/* Phone frame */}
      <div
        className="mx-auto relative"
        style={{ maxWidth: 390, minHeight: '100vh', paddingTop: 36 }}
      >
        {screen === 'splash' && <SplashScreen onPlay={() => go('home')} />}
        {screen === 'home' && (
          <HomeScreen onOpponents={() => go('opponents')} onCreate={() => go('create')} />
        )}
        {screen === 'opponents' && (
          <OpponentsScreen onSelect={handleOpponentSelect} onBack={() => go('home')} />
        )}
        {screen === 'create' && (
          <CreateScreen onCreate={handleCreate} onBack={() => go('home')} />
        )}
        {screen === 'waiting' && (
          <WaitingScreen onCancel={() => go('home')} bet={bet} />
        )}
        {screen === 'battle' && (
          <BattleScreen
            onChoice={handleChoice}
            onSurrender={() => { setOutcome('lose'); go('summary') }}
            opponentName={opponentName}
          />
        )}
        {screen === 'result' && (
          <ResultScreen
            playerChoice={playerChoice}
            opponentChoice={opponentChoice}
            outcome={outcome}
            opponentName={opponentName}
            bet={bet}
            onContinue={() => go('summary')}
          />
        )}
        {screen === 'summary' && (
          <SummaryScreen
            outcome={outcome}
            playerChoice={playerChoice}
            opponentChoice={opponentChoice}
            opponentName={opponentName}
            bet={bet}
            onRematch={() => go('waiting')}
            onMenu={() => go('home')}
          />
        )}
      </div>
    </div>
  )
}
